/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
public class Palindrome {
   public static void main(String[] args) {
      String str = "SATYA";
      StringBuffer newStr =new StringBuffer();
      for(int i = str.length()-1; i >= 0 ; i--) {
         newStr = newStr.append(str.charAt(i));
      }
      if(str.equalsIgnoreCase(newStr.toString())) {
         System.out.println("String is palindrome");
      } else {
         System.out.println("String is not palindrome");
      }
   }
}
